package com.me.myroadtripmap;

/**
 * Created by developer3 on 1/10/16.
 */
public class Location {
    float lat;
    float lon;
}
